class Div{
	public static void main(String[] args){
		float num = 6.66f;
		if(num%6.00==0){
			System.out.println(num+ " Is divisible by 6");
		}else{
			System.out.println(num+ " Is not divisible by 6");
		}
	}
}

