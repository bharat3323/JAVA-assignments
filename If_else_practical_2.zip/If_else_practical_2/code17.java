class Price{
	public static void main(String[] args){
		float costprice = 9000.23f;
		float sellingprice = 10000.23f;
		if(costprice<sellingprice){
			System.out.println("the profit of Rs" +(sellingprice-costprice));
		}else if(costprice>sellingprice){
                        System.out.println("the loss of Rs" +(costprice-sellingprice));
		}else if(costprice==sellingprice){
			System.out.println("no profit and loss");
		}else{
			System.out.println("Invalid input");
		}
	}
}
