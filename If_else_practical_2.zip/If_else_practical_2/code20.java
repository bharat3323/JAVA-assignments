class Fees{
	public static void main(String[] args){
		int fee = 5000;
		if(fee>=5000){
			System.out.println("Admission request is accept");
		}else if(fee==10000){
			System.out.println("Eligible for course");
		}else if(fee<5000 && fee>0){
			System.out.println("Admission will cancel soon");
		}else{
			System.out.println("Invalid input");
		}
	}
}

