class Student{
	public static void main(String[] args){
		float marks = 91.96f;
		if(marks>=90.00 && marks<=100.00){
			System.out.println("Passed :First class with distinction");
		}else if(marks<90.00 && marks>=80.00){
                        System.out.println("Passed :First class");
                }else if(marks<80.00 && marks>=70.00){
                        System.out.println("Passed :Second class ");
                }else if(marks<70.00 && marks>=60.00){
                        System.out.println("Passed :third class ");
                }else if(marks<60.00 && marks>=35.00){
                        System.out.println("Passed");
                }else if(marks<35.00){
                        System.out.println("Failed");
                }else{
			System.out.println("Invaild input");
		}
	}
}
