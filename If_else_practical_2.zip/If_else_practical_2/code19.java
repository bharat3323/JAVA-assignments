class Pythagorean{
	public static void main(String[] args){
		int a = 3;
		int b = 4;
		int c = 5;
		if(a*a+b*b==c*c){
			System.out.println(a+ " " +b + " " +c + " Is an pythagorean triplate");
		}else{
			System.out.println(a+ " " +b + " " +c + " Is not pythagorean triplate");
		}
	}
}

