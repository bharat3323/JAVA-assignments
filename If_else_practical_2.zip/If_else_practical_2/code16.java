class Vote{
	public static void main(String[] args){
		int age = 21;
		if(age>=18 && age>0){
			System.out.println("Valid age for voting");
		}else if(age<18 && age>0){
			System.out.println("Invalid age for voting");
		}else{
			System.out.println("Invalid input");
		}
	}
}
