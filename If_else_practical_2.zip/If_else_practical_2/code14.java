class Field{
	public static void main(String[] args){
		float percentage = 67.53f;
		if(percentage>85.00){
			System.out.println("Medical");
		}else if(percentage<=85.00 && percentage>75.00){
			System.out.println("Engineering");
		}else if(percentage<=75.00 && percentage>=65.00){
			System.out.println("Pharmacy or Bachelor in science");
		}else{
			System.out.println("Invalid input");
		}
	}
}
