class Range{
	public static void main(String[] args){
		int x = 100;
		if(x>=1 || x<=1000){
			System.out.println(x+ " Is in the range 1 to 1000");
		}else{
			System.out.println(x+ " Is not in the range 1 to 1000");
		}
	}
}

