class Vowel{
	public static void main(String[] args){
		char ch = 'a';
		if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U'){
			System.out.println(ch+ " Is an vowel");
		}else{
			System.out.println(ch+ " Is an consonant");
		}
	}
}

