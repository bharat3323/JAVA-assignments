class Table{
	public static void main(String[] args){
		int num = 156;
		if(num%13==0 && num<=130){
			System.out.println(num+ " Number is in the table of 13  ");
		}else if(num%13==0){
			System.out.println(num+ " Number is divisible by 13 but not present in 13 table");
		}else{
			System.out.println(num+ " Number is not divisibe by 13");
		}
	}
}
