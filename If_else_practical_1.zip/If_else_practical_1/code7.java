class maximum{
	public static void main(String[] args){
		int num1 = 5;
		int num2 = 9;
		if(num1 > num2){
			System.out.println("the maximum number is :"+num1);
		}else if(num1 < num2){
			System.out.println("the maximum number is :"+num2);
		}else{
			System.out.println(" number are equal");
		}
	}
}


