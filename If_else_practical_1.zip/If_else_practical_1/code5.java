class divisible{
	public static void main(String[] args){
		int num = 105;
		if(num%7==0){
			System.out.println("number is divisible by 7");
		}else{
			System.out.println("number is not divisible by 7");
		}
	}
}

