class Abc{
	public static void main(String[] args){
		int num = 63;
		if(num%3==0 && num%7==0){
                        System.out.println("number is  divisible by the 3 and 7");
		}else if(num%3==0){
			System.out.println("number is divisible by 3");
		}else if(num%7==0){
			System.out.println("number is divisible by 7");
		}
		else {
			System.out.println("number is  neither divisible by the 3 and 7");
		}
	}
	
}

	
