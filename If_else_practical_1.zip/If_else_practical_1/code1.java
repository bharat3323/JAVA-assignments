class demo{
	public static void main(String[] args){
		int num=54;
		if(num<0){
			System.out.println("number is negative");
		}else if(num>0){
			System.out.println("number is positive");
		}else{
			System.out.println("invalid input");
		}
	}
}
