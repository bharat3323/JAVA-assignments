class gl{
        public static void main(String[] args){
                int num = 17;
                if(num%2==0){
                        System.out.println("number is even");
                }else if(num%2==1){
                        System.out.println("number is odd");
                }else{
                        System.out.println("invalid input");
                }
		if(num<10){
			System.out.println("number is less than 10");
		}else{
			System.out.println("number is greater than 10");
		}
        }
}
