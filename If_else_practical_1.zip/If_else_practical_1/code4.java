class UL{
        public static void main(String[] args){
                char ch ='a';
		if(ch>='a' || ch<='z'){
			System.out.println("lowercase");
		}else {
			System.out.println("uppercase");
        }
	}
}
